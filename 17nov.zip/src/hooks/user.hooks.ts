// import { getUserProfile } from "@/services/userService";
// import { useQuery } from "@tanstack/react-query";

// export const useUserForgetPassword = (userId: string) => {
//   return useQuery<any, Error>({
//     queryKey: ["user_profile"],
//     queryFn: async () => await getUserProfile(userId),
//   });
// };
