"use server"
import { axiosSecure } from "@/lib/axiosInstance";

export const getCurrentUserProfile = async () => {
  try {
    const { data } = await axiosSecure.get(`/api/users/me`);
    return data;
  } catch (error: any) {
    throw new Error(error);
  }
};
