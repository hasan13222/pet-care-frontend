
const NotFound = () => {
    return (
        <div className="flex w-svw h-svh justify-center items-center">
            <h1>404. Page Not found</h1>
        </div>
    );
};

export default NotFound;